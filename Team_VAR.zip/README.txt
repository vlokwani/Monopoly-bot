# Team Name - VAR
# Agent file - Agent_Team_VAR.py
# Agent class - Agent
# Team Members - Vanshaj, Aayush, Ritika

# to use the agent, insert the below line:

from Agent_Team_Var import Agent
